# Releases

The **Weekly release** workflow runs every Sunday at 12:00 UTC. GitHub may
queue the run after that time. Weeks without new commits are skipped.

The release name uses the UTC ISO week year and week, such as `2026.35`.
The workflow updates `Cargo.toml` and `Cargo.lock`, commits `Release v2026.35`
on `main`, and atomically pushes that commit and its `v2026.35` tag.
It creates release notes using the existing section format and verifies the
published title and notes.

Web and native workflows receive the same tag and commit and run independently.
Web deploys when its own build finishes; native packages are attached as they
finish. The web deployment verifies `/app/release.json`, and the native
workflow verifies all five download files. Native update notices require a
download for the installed platform.

The app shows `2026.35`, Cargo and macOS use `2026.35.0`, and MSI uses `26.35.0`.
The main window title is `Open CAD Studio 2026.35 - Drawing.dwg`.

Builds that are not a clean checkout of the release tag carry build metadata:
`2026.35+194.gef189d77` means 194 first-parent commits past `v2026.35` at
commit `ef189d77`, and `.dirty` is appended when the tree has uncommitted
changes. `build.rs` derives this from git at compile time (`OCS_FULL_VERSION`);
without a tag to count from (shallow clone, source tarball) only the hash is
shown. The full form appears in About, **Copy Info**, `REPORT`, `--version`
and recovery reports. The window title, update check and User-Agent keep the
plain `2026.35`.

To preview release notes, manually run **Weekly release** on `main` with
**publish** unchecked. Check **publish** to release immediately. Rerunning
within the same week reuses the original tag and commit. To rebuild just a
failed target, use GitHub's **Re-run failed jobs**. Manual web deployment
defaults to the latest published release. For a web hotfix, run **Deploy web**
on `main` with **build_main** checked. The commit must descend from that release
and keep its package version; `/app/release.json` records the actual build commit
without moving the release tag.
