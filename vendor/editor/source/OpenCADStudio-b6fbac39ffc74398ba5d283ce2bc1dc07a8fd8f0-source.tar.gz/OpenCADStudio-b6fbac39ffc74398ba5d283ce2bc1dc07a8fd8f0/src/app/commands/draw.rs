use super::*;

impl OpenCADStudio {
    pub(super) fn dispatch_draw(&mut self, cmd: &str, i: usize) -> Option<Task<Message>> {
        match cmd {
            // ── Draw commands ──────────────────────────────────────────────
            "LINE" => {
                use crate::modules::draw::draw::line::LineCommand;
                let new_cmd = LineCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "MLINE" => {
                use crate::modules::draw::draw::mline::MlineCommand;
                let header = &self.tabs[i].scene.document.header;
                let style_name = header.multiline_style.clone();
                let scale = header.multiline_scale;
                let justification = header.multiline_justification;
                let styles = self.tabs[i]
                    .scene
                    .document
                    .objects
                    .iter()
                    .filter_map(|(handle, object)| match object {
                        codec::objects::ObjectType::MLineStyle(style) => {
                            Some((*handle, style.clone()))
                        }
                        _ => None,
                    })
                    .collect();
                let cmd_obj = MlineCommand::with_styles(styles, style_name, scale, justification);
                self.command_line.push_info(&cmd_obj.prompt());
                self.tabs[i].active_cmd = Some(Box::new(cmd_obj));
            }

            cmd if cmd == "WIPEOUT" || cmd == "WO" || cmd.starts_with("WIPEOUT ") => {
                use crate::modules::draw::draw::wipeout::WipeoutCommand;
                let args = cmd
                    .split_once(' ')
                    .map(|(_, r)| r.trim().to_uppercase())
                    .unwrap_or_default();
                let wo_cmd = match args.as_str() {
                    "P" | "POLYLINE" => WipeoutCommand::new_polyline(),
                    "R" | "RECTANGULAR" => WipeoutCommand::new_rectangular(),
                    _ => WipeoutCommand::new_polygonal(
                        crate::modules::draw::draw::wipeout::wipeout_frame_mode(
                            &self.tabs[i].scene.document,
                        ),
                    ),
                };
                self.command_line.push_info(&wo_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(wo_cmd));
            }

            cmd if cmd == "IMAGE" || cmd == "IMAGEATTACH" || cmd == "IM" => {
                return Some(Task::done(Message::ImagePick));
            }

            cmd if cmd == "IMAGEEMBED" => {
                return Some(Task::done(Message::ImageEmbedPick));
            }

            "REVCLOUD" | "REVCLOUD_RECTANGULAR" | "REVCLOUD_POLYGONAL" | "REVCLOUD_FREEHAND" => {
                use crate::modules::draw::draw::revcloud::RevCloudCommand;
                let view_height = self.tabs[i].scene.camera.borrow().ortho_size() as f64 * 2.0;
                let default_arc_length = (view_height * 0.0125).max(1.0e-6);
                let sources = self.tabs[i]
                    .scene
                    .document
                    .entities()
                    .map(|entity| (entity.common().handle, entity.clone()))
                    .collect();
                let mut command = RevCloudCommand::new(default_arc_length, sources);
                if let Some(mode) = cmd.strip_prefix("REVCLOUD_") {
                    command.on_text_input(mode);
                }
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            // Command-line attribute editing on selected Insert entities. Bare
            // ATTEDIT and the ATE alias launch the interactive editor instead
            // (see the ATTEDIT arm in the inquiry family); the dash form is the
            // command-line entry point.
            // Usage:
            //   -ATTEDIT          — list all attributes on selected Insert(s)
            //   ATTEDIT <tag> <v> — quick-set attribute <tag> to <v>
            cmd if cmd.starts_with("ATTEDIT ")
                || cmd == "-ATTEDIT"
                || cmd.starts_with("-ATTEDIT ") =>
            {
                let rest = cmd
                    .trim_start_matches("-ATTEDIT")
                    .trim_start_matches("ATTEDIT")
                    .trim();
                let parts: Vec<&str> = rest.splitn(2, char::is_whitespace).collect();
                let selected_handles: Vec<codec::Handle> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .iter()
                    .map(|(h, _)| *h)
                    .collect();
                if selected_handles.is_empty() {
                    self.command_line
                        .push_error(crate::t!("ATTEDIT: select an Insert entity first.").as_ref());
                } else {
                    let mut found_any = false;
                    for sh in &selected_handles {
                        if let Some(codec::EntityType::Insert(ins)) = self.tabs[i]
                            .scene
                            .document
                            .entities()
                            .find(|e| e.common().handle == *sh)
                        {
                            found_any = true;
                            if rest.is_empty() {
                                // List attributes.
                                if ins.attributes.is_empty() {
                                    self.command_line.push_output(
                                        crate::tf!("  Insert {:x}: no attributes.", sh.value())
                                            .as_ref(),
                                    );
                                } else {
                                    for attr in &ins.attributes {
                                        self.command_line.push_output(
                                            crate::tf!(
                                                "  [{tag}] = {val}",
                                                tag = attr.tag,
                                                val = attr.get_value()
                                            )
                                            .as_ref(),
                                        );
                                    }
                                }
                            }
                        }
                    }
                    if !found_any {
                        self.command_line.push_error(
                            crate::t!("ATTEDIT: no Insert entities in selection.").as_ref(),
                        );
                    }
                    // If tag + value supplied, mutate attributes.
                    if parts.len() == 2 && !parts[0].is_empty() {
                        let tag_up = parts[0].to_uppercase();
                        let new_val = parts[1];
                        let mut changed = 0usize;
                        self.push_undo_snapshot(i, "ATTEDIT");
                        for sh in &selected_handles {
                            if self.tabs[i].scene.is_layer_locked(*sh) {
                                continue;
                            }
                            if let Some(codec::EntityType::Insert(ins)) = self.tabs[i]
                                .scene
                                .document
                                .entities_mut()
                                .find(|e| e.common().handle == *sh)
                            {
                                for attr in &mut ins.attributes {
                                    if attr.tag.to_uppercase() == tag_up {
                                        attr.set_value(new_val);
                                        changed += 1;
                                    }
                                }
                            }
                        }
                        if changed > 0 {
                            self.tabs[i].dirty = true;
                            self.command_line.push_output(
                                crate::tf!(
                                "ATTEDIT: updated {changed} attribute(s) [{tag_up}] = {new_val}."
                            )
                                .as_ref(),
                            );
                        } else {
                            self.command_line.push_error(
                                crate::tf!("ATTEDIT: tag '{tag_up}' not found in selection.")
                                    .as_ref(),
                            );
                        }
                    }
                }
            }

            // ATTDISP sets ATTMODE: 0 hides every attribute, 1 shows the
            // visible ones, 2 shows them all. The definitions are not touched.
            "ATTDISP" => {
                let command = crate::modules::draw::draw::attdef::AttdispCommand::new(
                    self.tabs[i].scene.document.header.attribute_visibility,
                );
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }
            cmd if cmd.starts_with("ATTDISP ") => {
                let mode = match cmd[8..].trim().to_ascii_uppercase().as_str() {
                    "OFF" => 0,
                    "ON" => 2,
                    "NORMAL" | "N" => 1,
                    _ => {
                        self.command_line.push_error("Invalid option keyword.");
                        return Some(Task::none());
                    }
                };
                if self.tabs[i].scene.document.header.attribute_visibility != mode {
                    self.push_undo_snapshot(i, "ATTDISP");
                    self.tabs[i].scene.document.header.attribute_visibility = mode;
                    self.tabs[i].dirty = true;
                    self.tabs[i].scene.bump_geometry();
                }
                self.command_line.push_output("Regenerating model.");
            }

            "DONUT" => {
                use crate::modules::draw::draw::donut::DonutCommand;
                let cmd = DonutCommand::new();
                self.command_line.push_info(&cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(cmd));
            }

            "CIRCLE" => {
                use crate::modules::draw::draw::circle::CircleCommand;
                let new_cmd = CircleCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "CIRCLE_CD" => {
                use crate::modules::draw::draw::circle::CircleCDCommand;
                let new_cmd = CircleCDCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "CIRCLE_2P" => {
                use crate::modules::draw::draw::circle::Circle2PCommand;
                let new_cmd = Circle2PCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "CIRCLE_3P" => {
                use crate::modules::draw::draw::circle::Circle3PCommand;
                let new_cmd = Circle3PCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "CIRCLE_TTR" => {
                use crate::modules::draw::draw::circle::CircleTTRCommand;
                let new_cmd = CircleTTRCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.pre_cmd_tangent = Some(self.snapper.is_on(crate::snap::SnapType::Tangent));
                self.snapper.enabled.insert(crate::snap::SnapType::Tangent);
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "CIRCLE_TTT" => {
                use crate::modules::draw::draw::circle::CircleTTTCommand;
                let new_cmd = CircleTTTCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.pre_cmd_tangent = Some(self.snapper.is_on(crate::snap::SnapType::Tangent));
                self.snapper.enabled.insert(crate::snap::SnapType::Tangent);
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "ARC" => {
                use crate::modules::draw::draw::arc::ArcCommand;
                let new_cmd = ArcCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_3P" => {
                use crate::modules::draw::draw::arc::Arc3PCommand;
                let new_cmd = Arc3PCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_CSE" => {
                use crate::modules::draw::draw::arc::ArcCSECommand;
                let new_cmd = ArcCSECommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SCE" => {
                use crate::modules::draw::draw::arc::ArcSCECommand;
                let new_cmd = ArcSCECommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SCA" => {
                use crate::modules::draw::draw::arc::ArcSCACommand;
                let new_cmd = ArcSCACommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SCL" => {
                use crate::modules::draw::draw::arc::ArcSCLCommand;
                let new_cmd = ArcSCLCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SEA" => {
                use crate::modules::draw::draw::arc::ArcSEACommand;
                let new_cmd = ArcSEACommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SER" => {
                use crate::modules::draw::draw::arc::ArcSERCommand;
                let new_cmd = ArcSERCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_SED" => {
                use crate::modules::draw::draw::arc::ArcSEDCommand;
                let new_cmd = ArcSEDCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_CSA" => {
                use crate::modules::draw::draw::arc::ArcCSACommand;
                let new_cmd = ArcCSACommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_CSL" => {
                use crate::modules::draw::draw::arc::ArcCSLCommand;
                let new_cmd = ArcCSLCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "ARC_CONT" => {
                use crate::modules::draw::draw::arc::{continue_anchor, ArcContCommand};
                // Prefer the anchor recorded when the last line/arc was drawn (it
                // knows the true drawing-end tangent); otherwise fall back to the
                // last line/arc found in the document (e.g. after a file load).
                let seed = self.cont_anchor.or_else(|| {
                    self.tabs[i]
                        .scene
                        .document
                        .entities()
                        .filter_map(|e| continue_anchor(e, None))
                        .last()
                });
                match seed {
                    Some((s, tangent)) => {
                        self.last_point = Some(s);
                        let new_cmd = ArcContCommand::new(s, tangent);
                        self.command_line.push_info(&new_cmd.prompt());
                        self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                    }
                    None => {
                        self.command_line.push_info(
                            crate::t!("ARC Continue  No previous line or arc to continue.")
                                .as_ref(),
                        );
                    }
                }
            }

            "RECT" | "RECTANG" => {
                use crate::modules::draw::draw::shapes::RectCommand;
                let new_cmd = RectCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                if self.ortho_mode {
                    self.rect_suppressed_ortho = true;
                    self.ortho_mode = false;
                }
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "RECT_ROT" => {
                use crate::modules::draw::draw::shapes::RectRotCommand;
                let new_cmd = RectRotCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                if self.ortho_mode {
                    self.rect_suppressed_ortho = true;
                    self.ortho_mode = false;
                }
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "RECT_CEN" => {
                use crate::modules::draw::draw::shapes::RectCenCommand;
                let new_cmd = RectCenCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                if self.ortho_mode {
                    self.rect_suppressed_ortho = true;
                    self.ortho_mode = false;
                }
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "POLY" | "POLYGON" => {
                use crate::modules::draw::draw::shapes::PolyCommand;
                let new_cmd = PolyCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "POLY_C" => {
                use crate::modules::draw::draw::shapes::PolyCCommand;
                let new_cmd = PolyCCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "POLY_E" => {
                use crate::modules::draw::draw::shapes::PolyECommand;
                let new_cmd = PolyECommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "PLINE" => {
                use crate::modules::draw::draw::polyline::PlineCommand;
                let new_cmd = PlineCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "3DPOLY" => {
                use crate::modules::draw::draw::poly3d::Poly3dCommand;
                let new_cmd = Poly3dCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "3DMESH" => {
                use crate::modules::draw::draw::mesh3d::Mesh3dCommand;
                let new_cmd = Mesh3dCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "3DFACE" => {
                use crate::modules::draw::draw::face3d::Face3dCommand;
                let new_cmd = Face3dCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "EDGE" => {
                use crate::modules::draw::draw::face3d::FaceEdgeCommand;
                let faces = self.tabs[i]
                    .scene
                    .document
                    .entities()
                    .filter_map(|entity| match entity {
                        codec::EntityType::Face3D(face) => Some((face.common.handle, face.clone())),
                        _ => None,
                    })
                    .collect();
                let new_cmd = FaceEdgeCommand::new(faces);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            // 2D filled solid. Reached via SO / SOLID2D — the bare SOLID verb is
            // currently the shaded-display toggle (token collision tracked).
            "SOLID" | "SOLID2D" => {
                use crate::modules::draw::draw::solid2d::Solid2dCommand;
                let new_cmd = Solid2dCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "HELIX" => {
                use crate::modules::draw::draw::helix::HelixCommand;
                let new_cmd = HelixCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "TRACE" => {
                use crate::modules::draw::draw::trace::TraceCommand;
                let new_cmd = TraceCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "CENTERLINE" => {
                use crate::modules::draw::draw::centerline::CenterLineCommand;
                let settings = self.tabs[i].scene.centerline_settings();
                let new_cmd = CenterLineCommand::new(settings);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "CENTERRESET" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                self.push_undo_snapshot(i, "CENTERRESET");
                let count = self.tabs[i].scene.reset_centerlines(&handles)
                    + self.tabs[i].scene.reset_center_marks(&handles);
                if count > 0 {
                    self.tabs[i].dirty = true;
                }
                self.command_line.push_output(&crate::tf!(
                    "CENTERRESET: {count} center object(s) updated."
                ));
            }

            "CENTERREASSOCIATE" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                let mark_targets: Vec<_> = handles
                    .iter()
                    .copied()
                    .filter(|handle| {
                        let Some(codec::EntityType::Line(line)) =
                            self.tabs[i].scene.document.get_entity(*handle)
                        else {
                            return false;
                        };
                        codec::entities::CenterMarkAssociation::read(&line.common.extended_data)
                            .is_some()
                    })
                    .collect();
                if mark_targets.len() == 1 && handles.len() == 1 {
                    use crate::modules::draw::draw::dimcenter::CenterMarkReassociateCommand;
                    let new_cmd = CenterMarkReassociateCommand::new(mark_targets[0]);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                    return Some(self.finish_dispatch(cmd));
                }
                self.push_undo_snapshot(i, "CENTERREASSOCIATE");
                let count = self.tabs[i]
                    .scene
                    .set_centerline_association(&handles, true)
                    + self.tabs[i]
                        .scene
                        .set_center_mark_association(&handles, true);
                if count > 0 {
                    self.tabs[i].dirty = true;
                }
                self.command_line.push_output(&crate::tf!(
                    "CENTERREASSOCIATE: {count} center object(s) associated."
                ));
            }

            "CENTERDISASSOCIATE" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                self.push_undo_snapshot(i, "CENTERDISASSOCIATE");
                let count = self.tabs[i]
                    .scene
                    .set_centerline_association(&handles, false)
                    + self.tabs[i]
                        .scene
                        .set_center_mark_association(&handles, false);
                if count > 0 {
                    self.tabs[i].dirty = true;
                }
                self.command_line.push_output(&crate::tf!(
                    "CENTERDISASSOCIATE: {count} center object(s) detached."
                ));
            }

            "DIMCENTER" => {
                use crate::modules::draw::draw::dimcenter::DimCenterCommand;
                let new_cmd = DimCenterCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "CENTERMARK" => {
                use crate::modules::draw::draw::dimcenter::CenterMarkCommand;
                let settings = self.tabs[i].scene.centerline_settings();
                let new_cmd = CenterMarkCommand::new(settings);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "SKETCH" => {
                use crate::modules::draw::draw::sketch::SketchCommand;
                let header = &self.tabs[i].scene.document.header;
                let new_cmd = SketchCommand::new(
                    header.sketch_type,
                    header.sketch_increment,
                    header.sketch_tolerance,
                );
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "REVERSE" => {
                use crate::modules::draw::modify::reverse::ReverseCommand;
                if self.tabs[i].scene.selected.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let selection = SelectObjectsCommand::new("REVERSE");
                    self.command_line.push_info(&selection.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(selection));
                } else {
                    let replacements = self.tabs[i]
                        .scene
                        .selected_entities()
                        .into_iter()
                        .filter(|(handle, _)| !self.tabs[i].scene.is_layer_locked(*handle))
                        .filter_map(|(handle, entity)| {
                            ReverseCommand::reversed(entity)
                                .map(|reversed| (handle, vec![reversed]))
                        })
                        .collect::<Vec<_>>();
                    if !replacements.is_empty() {
                        return Some(self.apply_cmd_result(
                            crate::command::CmdResult::ReplaceMany(replacements, Vec::new()),
                        ));
                    }
                }
            }

            "MEASUREGEOM" | "MEASURERADIUS" | "MEASUREANGLE" => {
                use crate::modules::draw::inquiry::measuregeom::MeasureGeomCommand;
                let new_cmd = match cmd {
                    "MEASURERADIUS" => MeasureGeomCommand::radius(),
                    "MEASUREANGLE" => MeasureGeomCommand::angle(),
                    _ => MeasureGeomCommand::new(),
                };
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            // ── Modify commands ────────────────────────────────────────────
            // MOVE works from picked points, so it already relocates entities
            // in 3D; 3DMOVE is the same operation.
            "MOVE" | "3DMOVE" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .filter(|handle| !self.tabs[i].scene.is_layer_locked(*handle))
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("MOVE");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::translate::MoveCommand;
                    let wires = self.tabs[i].scene.wire_models_for(&handles);
                    let new_cmd = MoveCommand::new(handles, wires);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "COPY" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("COPY");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::copy::CopyCommand;
                    let wires = self.tabs[i].scene.wire_models_for(&handles);
                    let new_cmd = CopyCommand::new(handles, wires);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "ROTATE" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("ROTATE");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::rotate::RotateCommand;
                    let wires = self.tabs[i].scene.wire_models_for(&handles);
                    let new_cmd = RotateCommand::new(handles, wires);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "TORIENT" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("TORIENT");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::torient::TorientCommand;
                    let entities: Vec<_> = handles
                        .iter()
                        .filter_map(|&h| {
                            self.tabs[i]
                                .scene
                                .document
                                .get_entity(h)
                                .cloned()
                                .map(|e| (h, e))
                        })
                        .collect();
                    let cam_rot = self.tabs[i].scene.camera.borrow().rotation;
                    let right = cam_rot * glam::Vec3::X;
                    let view_twist = right.y.atan2(right.x) as f64;
                    let new_cmd = TorientCommand::new(entities, view_twist);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "POINT" | "MULTIPOINT" => {
                use crate::modules::draw::draw::point::PointCommand;
                let new_cmd = if cmd == "MULTIPOINT" {
                    PointCommand::multiple()
                } else {
                    PointCommand::new()
                };
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "RAY" => {
                use crate::modules::draw::draw::ray::RayCommand;
                let new_cmd = RayCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "XLINE" | "CONSTRUCTIONLINE" => {
                use crate::modules::draw::draw::ray::XLineCommand;
                let new_cmd = XLineCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "HATCH" => {
                use crate::modules::draw::draw::hatch::HatchCommand;
                let working_plane = if self.tabs[i].editing_model_space() {
                    self.tabs[i].ucs_xform().working_plane()
                } else {
                    crate::command::WorkingPlane::default()
                };
                let normal = working_plane.z.normalize_or(glam::DVec3::Z);
                let elevation = working_plane.origin.dot(normal);
                let storage = crate::entities::curve::ocs_plane(
                    codec::types::Vector3::new(normal.x, normal.y, normal.z),
                    elevation,
                );
                let plane = crate::command::WorkingPlane::new(
                    glam::DVec3::from_array(storage.origin),
                    glam::DVec3::from_array(storage.x_axis),
                    glam::DVec3::from_array(storage.y_axis),
                );
                let boundary_sources = self.tabs[i].scene.boundary_sources_on_plane(plane, 1.0e-6);
                let outlines = crate::scene::boundary_faces(&boundary_sources, 1.0e-6);
                let selected = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(handle, _)| handle)
                    .collect::<Vec<_>>();
                let inherited = selected.iter().find_map(|handle| {
                    let model = self.tabs[i].scene.hatches.get(handle)?.clone();
                    let common = self.tabs[i].scene.document.get_entity(*handle)?.common();
                    Some((model, common.color.clone(), common.transparency))
                });
                let new_cmd =
                    HatchCommand::new(outlines, boundary_sources, selected, inherited, plane)
                        .with_origin(self.tabs[i].scene.document.hatch_origin())
                        .with_associative(self.hatch_associative);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                self.refresh_area_preview(i);
            }

            "HATCHEDIT" => {
                use crate::modules::draw::draw::hatchedit::HatcheditCommand;
                // If a single hatch is already selected, skip the pick step.
                let sel = self.tabs[i].scene.selected_entities();
                if sel.len() == 1 {
                    let (h, _) = sel[0];
                    if let Some(model) = self.tabs[i].scene.hatches.get(&h).cloned() {
                        let entity = self.tabs[i].scene.document.get_entity(h);
                        let annotative = entity.is_some_and(|entity| {
                            crate::scene::annotative::is_annotative(
                                &self.tabs[i].scene.document,
                                entity,
                            )
                        });
                        let (scale, angle) = match entity {
                            Some(codec::EntityType::Hatch(hatch)) => (
                                hatch.pattern_scale as f32,
                                hatch.pattern_angle.to_degrees() as f32,
                            ),
                            _ => (model.scale, model.angle_offset.to_degrees()),
                        };
                        let cmd = HatcheditCommand::with_handle(
                            h,
                            model.name.clone(),
                            scale,
                            angle,
                            annotative,
                        )
                        .with_appearance(
                            entity,
                            self.tabs[i].scene.document.header.current_entity_color,
                            self.tabs[i].scene.document.current_entity_transparency(),
                        )
                        .with_origin(self.tabs[i].scene.document.hatch_origin());
                        self.command_line.push_info(&cmd.prompt());
                        self.tabs[i].active_cmd = Some(Box::new(cmd));
                    } else {
                        self.command_line.push_error(
                            crate::t!("HATCHEDIT: selected entity is not a hatch.").as_ref(),
                        );
                    }
                } else {
                    let cmd = HatcheditCommand::new()
                        .with_appearance(
                            None,
                            self.tabs[i].scene.document.header.current_entity_color,
                            self.tabs[i].scene.document.current_entity_transparency(),
                        )
                        .with_origin(self.tabs[i].scene.document.hatch_origin());
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                }
            }

            "GRADIENT" => {
                use crate::modules::draw::draw::hatch::GradientCommand;
                let boundary_sources = self.tabs[i]
                    .scene
                    .boundary_sources_on_plane(crate::command::WorkingPlane::default(), 1.0e-6);
                let outlines = crate::scene::boundary_faces(&boundary_sources, 1.0e-6);
                let new_cmd = GradientCommand::new(outlines, boundary_sources);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "BOUNDARY" => {
                use crate::modules::draw::draw::hatch::BoundaryCommand;
                let plane = if self.tabs[i].editing_model_space() {
                    self.tabs[i].ucs_xform().working_plane()
                } else {
                    crate::command::WorkingPlane::default()
                };
                let sources = self.tabs[i].scene.boundary_sources_on_plane(plane, 1.0e-6);
                let selected = self.tabs[i]
                    .scene
                    .selected_entities()
                    .iter()
                    .map(|(handle, _)| *handle)
                    .collect();
                let new_cmd = BoundaryCommand::new(sources, selected, plane);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "ELLIPSE" => {
                use crate::modules::draw::draw::ellipse::EllipseCommand;
                let new_cmd = EllipseCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "ELLIPSE_AXIS" => {
                use crate::modules::draw::draw::ellipse::EllipseAxisCommand;
                let new_cmd = EllipseAxisCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "ELLIPSE_ARC" => {
                use crate::modules::draw::draw::ellipse::EllipseArcCommand;
                let new_cmd = EllipseArcCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "SPLINE" | "SPLINECV" => {
                use crate::modules::draw::draw::spline::SplineCommand;
                let new_cmd = if cmd == "SPLINECV" {
                    SplineCommand::control_vertices()
                } else {
                    SplineCommand::new()
                }
                .with_document(&self.tabs[i].scene.document);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "SCALE" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("SCALE");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::scale::ScaleCommand;
                    let wires = self.tabs[i].scene.wire_models_for(&handles);
                    let new_cmd = ScaleCommand::new(handles, wires);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "MIRROR" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("MIRROR");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::mirror::MirrorCommand;
                    let (wires, text_ghosts) = self.tabs[i].scene.mirror_preview_parts(&handles);
                    let mirror_text = self.tabs[i].scene.document.header.mirror_text;
                    let new_cmd = MirrorCommand::new(handles, wires, text_ghosts, mirror_text);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "ERASE" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .filter(|handle| !self.tabs[i].scene.is_layer_locked(*handle))
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("ERASE");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    let n = handles.len();
                    let delta_safe = self.delta_erase_safe(i, &handles);
                    let pending = self.begin_undo(i, "ERASE", handles.len(), delta_safe);
                    // Stash the erased entities so OOPS can restore them.
                    self.oops_cache = handles
                        .iter()
                        .filter_map(|h| self.tabs[i].scene.document.get_entity_arc(*h))
                        .collect();
                    self.tabs[i].scene.erase_entities(&handles);
                    self.tabs[i].dirty = true;
                    self.refresh_properties();
                    self.command_line
                        .push_output(crate::tf!("{n} object(s) erased.").as_ref());
                    if let Some(pd) = pending {
                        self.commit_undo_delta(i, pd);
                    }
                }
            }

            // ── Persistent constraints ────────────────────────────────────
            "CONSTRAINTBAR" | "CONSTRAINTBAR_OPTIONS" => {
                use crate::modules::parametric::ConstraintBarOptionCommand;

                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() && cmd == "CONSTRAINTBAR" {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let command =
                        SelectObjectsCommand::routed("CONSTRAINTBAR", "CONSTRAINTBAR_OPTIONS");
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else if handles.is_empty() {
                    self.command_line.push_output("No objects selected.");
                } else {
                    let command = ConstraintBarOptionCommand::new(handles);
                    self.command_line.push_info(&command.prompt());
                    self.command_line.set_step_options(command.options());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "GCSHOW" | "GCHIDE" | "DCSHOW" | "DCHIDE" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else {
                    let scope = self.tabs[i].current_parametric_scope();
                    let dimensional = cmd.starts_with("DC");
                    let visible = !matches!(cmd, "GCHIDE" | "DCHIDE");
                    let count = self.tabs[i].scene.set_parametric_constraint_visibility(
                        scope,
                        Some(&handles),
                        dimensional,
                        visible,
                    );
                    self.command_line.push_output(
                        format!("{} constraint indicator(s) updated.", count).as_str(),
                    );
                }
            }

            "GCRESET" => {
                let scope = self.tabs[i].current_parametric_scope();
                let count = self.tabs[i]
                    .scene
                    .set_parametric_constraint_visibility(scope, None, false, true);
                self.command_line
                    .push_output(format!("{} constraint indicator(s) reset.", count).as_str());
            }

            "CONSTRAINTBAR_RESET" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    self.command_line.push_output("No objects selected.");
                } else {
                    let scope = self.tabs[i].current_parametric_scope();
                    let count = self.tabs[i].scene.set_parametric_constraint_visibility(
                        scope,
                        Some(&handles),
                        false,
                        true,
                    );
                    self.command_line
                        .push_output(format!("{} constraint bar(s) reset.", count).as_str());
                }
            }

            "GCSHOWALL" | "GCHIDEALL" | "DCSHOWALL" | "DCHIDEALL" => {
                let scope = self.tabs[i].current_parametric_scope();
                let dimensional = cmd.starts_with("DC");
                let visible = matches!(cmd, "GCSHOWALL" | "DCSHOWALL");
                let count = self.tabs[i].scene.set_parametric_constraint_visibility(
                    scope,
                    None,
                    dimensional,
                    visible,
                );
                self.command_line
                    .push_output(format!("{} constraint indicator(s) updated.", count).as_str());
            }

            "DELCONSTRAINT" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else {
                    let scope = self.tabs[i].current_parametric_scope();
                    let Some(before) = self.tabs[i].scene.parametric_constraint_set(scope).cloned()
                    else {
                        self.command_line.push_output("No constraints found.");
                        return None;
                    };
                    let mut ids: Vec<_> = before
                        .constraints
                        .iter()
                        .filter(|constraint| {
                            constraint
                                .refs
                                .iter()
                                .any(|reference| handles.contains(&reference.entity))
                        })
                        .map(|constraint| constraint.id)
                        .collect();
                    ids.sort_unstable();
                    ids.dedup();
                    if ids.is_empty() {
                        self.command_line.push_output("No constraints found.");
                        return None;
                    }
                    let dimensions: Vec<codec::Handle> = ids
                        .iter()
                        .filter_map(|id| before.dimensions.get(id).copied())
                        .collect();
                    let parameters: Vec<String> = ids
                        .iter()
                        .filter_map(|id| before.get(*id))
                        .filter_map(|constraint| match &constraint.driving_param {
                            Some(crate::scene::named_parameters::DrivingValue::Named(name)) => {
                                Some(name.clone())
                            }
                            _ => None,
                        })
                        .collect();
                    let pending = self.begin_undo(
                        i,
                        "Delete constraints",
                        handles.len(),
                        dimensions.is_empty(),
                    );
                    self.tabs[i]
                        .scene
                        .record_undo_parametric_constraints_before(scope, before);
                    let set = self.tabs[i].scene.parametric_constraint_set_mut(scope);
                    for id in &ids {
                        set.remove(*id);
                    }
                    self.purge_dimensional_extras(i, dimensions, parameters);
                    self.tabs[i].scene.bump_constraints_epoch();
                    let changes: Vec<_> = handles
                        .iter()
                        .copied()
                        .map(|handle| (handle, crate::scene::ChangeKind::Modified))
                        .collect();
                    self.tabs[i].scene.bump_entities(&changes);
                    self.tabs[i].dirty = true;
                    self.refresh_properties();
                    self.command_line
                        .push_output(format!("{} constraint(s) deleted.", ids.len()).as_str());
                    if let Some(pd) = pending {
                        self.commit_undo_delta(i, pd);
                    }
                }
            }

            "CONSTRAINTSETTINGS" => {
                self.auto_constrain_saved = Some(self.auto_constrain_settings.clone());
                self.auto_constrain_selected_row = 0;
                self.auto_constrain_distance_input =
                    format!("{}", self.auto_constrain_settings.distance_tolerance);
                self.auto_constrain_angle_input =
                    format!("{}", self.auto_constrain_settings.angle_tolerance_deg);
                self.active_modal = Some(crate::app::ModalKind::AutoConstrainSettings);
            }

            "AUTOCONSTRAIN" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::auto_constrain(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else {
                    let scope = self.tabs[i].current_parametric_scope();
                    let inferred = self.tabs[i].scene.inferred_parametric_constraints(
                        scope,
                        &handles,
                        &self.auto_constrain_settings,
                    );
                    if inferred.is_empty() {
                        self.command_line.push_output(
                            format!("0 constraint(s) applied to {} object(s).", handles.len())
                                .as_str(),
                        );
                        self.tabs[i].scene.deselect_all();
                        self.refresh_selected_grips();
                    } else {
                        let before = self.tabs[i]
                            .scene
                            .parametric_constraint_set(scope)
                            .cloned()
                            .unwrap_or_else(|| {
                                crate::scene::parametric_constraints::ParametricConstraintSet::new(
                                    scope,
                                )
                            });
                        let pending = self.begin_undo(i, "Auto constrain", handles.len(), true);
                        self.tabs[i]
                            .scene
                            .record_undo_parametric_constraints_before(scope, before);
                        let count = inferred.len();
                        for (kind, refs) in inferred {
                            let id = self.tabs[i]
                                .scene
                                .parametric_constraint_set_mut(scope)
                                .add(kind, refs, None);
                            self.tabs[i].scene.note_parametric_constraint_applied(
                                scope,
                                id,
                                self.constraint_bar_display,
                            );
                        }
                        let changes: Vec<_> = handles
                            .iter()
                            .copied()
                            .map(|handle| (handle, crate::scene::ChangeKind::Modified))
                            .collect();
                        self.tabs[i].scene.bump_entities_with_parametric_policy(
                            &changes,
                            &[],
                            self.constraint_solve_mode,
                        );
                        self.tabs[i].dirty = true;
                        self.refresh_properties();
                        self.command_line.push_output(
                            format!(
                                "{} constraint(s) applied to {} object(s).",
                                count,
                                handles.len()
                            )
                            .as_str(),
                        );
                        if let Some(pd) = pending {
                            self.commit_undo_delta(i, pd);
                        }
                    }
                }
            }

            "GCSMOOTH" => {
                use crate::modules::parametric::SmoothConstraintCommand;
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    let command = SmoothConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else if handles.len() != 2 {
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(
                        "Smooth requires an open spline first and a target curve second.",
                    );
                    let command = SmoothConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else {
                    let first = self.tabs[i].scene.document.get_entity(handles[0]);
                    let second = self.tabs[i].scene.document.get_entity(handles[1]);
                    let refs = first.zip(second).and_then(|(first, second)| {
                        SmoothConstraintCommand::preselected_refs(
                            (first, handles[0]),
                            (second, handles[1]),
                        )
                    });
                    let Some(refs) = refs else {
                        self.tabs[i].scene.deselect_all();
                        self.command_line.push_error(
                            "Smooth requires an open spline first and a line, arc, polyline segment or open spline second.",
                        );
                        let command = SmoothConstraintCommand::new();
                        self.command_line.push_info(&command.prompt());
                        self.tabs[i].active_cmd = Some(Box::new(command));
                        return None;
                    };
                    use crate::command::CmdResult;
                    use crate::scene::parametric_constraints::ConstraintKind;
                    return Some(self.apply_cmd_result(CmdResult::AddParametricConstraint {
                        kind: ConstraintKind::Smooth,
                        refs,
                        driving_param: None,
                        label: "Smooth constraint",
                    }));
                }
            }

            // A pre-selection is not used: the reference always asks, and it
            // gathers associative dimensions only.
            "DCCONVERT" => {
                use crate::modules::draw::select::SelectObjectsCommand;
                self.tabs[i].scene.deselect_all();
                let sel = SelectObjectsCommand::associative_dimensions(
                    cmd,
                    "DCCONVERTAPPLY",
                    "Select associative dimensions to convert:",
                );
                self.command_line.push_info(&sel.prompt());
                self.tabs[i].active_cmd = Some(Box::new(sel));
            }

            // The gathered dimensions become dimensional constraints: each one
            // keeps its dimension, which turns into the constraint's dynamic
            // (or annotational) dimension driven by a new parameter.
            "DCCONVERTAPPLY" => {
                use crate::scene::named_parameters::DrivingValue;
                use crate::scene::parametric_constraints::{
                    dynamic_dimension_text, next_angular_parameter_name,
                    next_dimensional_parameter_name, next_radial_parameter_name, ConstraintKind,
                };

                let scope = self.tabs[i].current_parametric_scope();
                let handles = self.tabs[i].scene.selected_handles_in_order();
                let annotational = self.constraint_form_annotational;
                let mut table = self.tabs[i].scene.named_parameters().clone();
                let mut conversions = Vec::new();
                let mut refused = 0usize;
                for handle in handles {
                    if self.tabs[i].scene.is_layer_locked(handle) {
                        refused += 1;
                        continue;
                    }
                    // A dimension already driving a constraint is not converted
                    // a second time.
                    if crate::scene::parametric_constraints::dynamic_dimension_constraint(
                        &self.tabs[i].scene.parametric_constraints,
                        handle,
                    )
                    .is_some()
                    {
                        refused += 1;
                        continue;
                    }
                    let Some((kind, refs, value)) =
                        crate::scene::dimension_assoc::constraint_from_associative_dimension(
                            &self.tabs[i].scene.document,
                            handle,
                        )
                    else {
                        refused += 1;
                        continue;
                    };
                    let DrivingValue::Literal(measured) = value else {
                        refused += 1;
                        continue;
                    };
                    if self.tabs[i]
                        .scene
                        .validate_parametric_constraint(
                            kind,
                            &refs,
                            Some(&DrivingValue::Literal(measured)),
                        )
                        .is_err()
                    {
                        refused += 1;
                        continue;
                    }
                    // The parameter is named after the constraint it drives,
                    // as a constraint made by hand would be.
                    let name = match kind {
                        ConstraintKind::Radius => next_radial_parameter_name(&table, false),
                        ConstraintKind::Diameter => next_radial_parameter_name(&table, true),
                        ConstraintKind::Angle | ConstraintKind::Angle3Point => {
                            next_angular_parameter_name(&table)
                        }
                        _ => next_dimensional_parameter_name(&table),
                    };
                    let expression =
                        crate::scene::parametric_constraints::measured_expression(measured);
                    if table.set(&name, &expression).is_err() {
                        refused += 1;
                        continue;
                    }
                    conversions.push((handle, kind, refs, name, expression, measured));
                }
                if conversions.is_empty() {
                    self.command_line
                        .push_output(crate::t!("0 associative dimensions converted").as_ref());
                    self.command_line.push_output(
                        crate::tf!("{refused} associative dimension(s) could not be converted")
                            .as_ref(),
                    );
                    self.tabs[i].scene.deselect_all();
                    self.refresh_properties();
                    return None;
                }
                let constraints_before = self.tabs[i]
                    .scene
                    .parametric_constraint_set(scope)
                    .cloned()
                    .unwrap_or_else(|| {
                        crate::scene::parametric_constraints::ParametricConstraintSet::new(scope)
                    });
                let mut touched: Vec<_> = conversions
                    .iter()
                    .flat_map(|(_, _, refs, _, _, _)| refs.iter().map(|r| r.entity))
                    .collect();
                touched.sort_unstable();
                touched.dedup();
                // The constraints layer is made before the recording opens: a
                // new layer inside it would cost the delta its entity undo.
                if !annotational {
                    self.tabs[i].scene.ensure_dynamic_dimension_layer();
                }
                let pending = self.begin_undo(
                    i,
                    "Convert dimensions to constraints",
                    touched.len() + conversions.len(),
                    false,
                );
                self.tabs[i]
                    .scene
                    .record_undo_parametric_constraints_before(scope, constraints_before);
                self.tabs[i].scene.record_undo_named_parameters_before();
                self.tabs[i].scene.named_parameters = table;
                let format = self.tabs[i].scene.constraint_name_format;
                let converted = conversions.len();
                for (handle, kind, refs, name, expression, measured) in conversions {
                    let angular =
                        matches!(kind, ConstraintKind::Angle | ConstraintKind::Angle3Point);
                    let decimals = angular.then(|| {
                        crate::scene::parametric_constraints::angle_decimals(
                            &self.tabs[i].scene.document,
                            None,
                        )
                    });
                    let text = dynamic_dimension_text(
                        &name,
                        measured,
                        format,
                        false,
                        Some(&expression),
                        annotational,
                        decimals,
                    );
                    if let Some(codec::EntityType::Dimension(mut dimension)) =
                        self.tabs[i].scene.document.get_entity(handle).cloned()
                    {
                        let before = self.tabs[i].scene.document.get_entity_arc(handle);
                        self.tabs[i].scene.record_undo_before(handle, before);
                        crate::entities::dimension::set_dimension_text_override(
                            dimension.base_mut(),
                            Some(text),
                        );
                        // The dynamic form lives on the reference's hidden
                        // constraints layer in the constraint grey; the
                        // annotational form stays where the dimension is.
                        if !annotational {
                            dimension.base_mut().common.layer =
                                crate::scene::parametric_constraints::DYNAMIC_DIMENSION_LAYER
                                    .to_string();
                            dimension.base_mut().common.color = codec::types::Color::Rgb {
                                r: 103,
                                g: 109,
                                b: 118,
                            };
                        }
                        self.tabs[i]
                            .scene
                            .update_entity(codec::EntityType::Dimension(dimension));
                    }
                    let set = self.tabs[i].scene.parametric_constraint_set_mut(scope);
                    let id = set.add(kind, refs, Some(DrivingValue::Named(name)));
                    set.dimensions.insert(id, handle);
                    self.tabs[i].scene.note_parametric_constraint_applied(
                        scope,
                        id,
                        self.constraint_bar_display,
                    );
                }
                let changes: Vec<_> = touched
                    .into_iter()
                    .map(|handle| (handle, crate::scene::ChangeKind::Modified))
                    .collect();
                self.tabs[i].scene.bump_entities(&changes);
                self.tabs[i].scene.refresh_hidden_dynamic_dimensions();
                self.tabs[i].scene.refresh_dynamic_dimension_scales(true);
                self.tabs[i].scene.deselect_all();
                self.tabs[i].dirty = true;
                self.refresh_properties();
                self.command_line.push_output(
                    crate::tf!("{converted} associative dimensions converted").as_ref(),
                );
                self.command_line.push_output(
                    crate::tf!("{refused} associative dimension(s) could not be converted")
                        .as_ref(),
                );
                if let Some(pd) = pending {
                    self.commit_undo_delta(i, pd);
                }
            }

            "GCHORIZONTAL" | "VCONSTRAINT" | "GCVERTICAL" => {
                use crate::command::{CmdResult, HorizontalConstraintSelection};
                use crate::modules::parametric::HorizontalConstraintCommand;
                use crate::scene::parametric_constraints::ConstraintKind;

                // Vertical is Horizontal mirrored onto the working plane's Y
                // axis: same picks, same 2Points flow, same reference types.
                let vertical = cmd != "GCHORIZONTAL";
                let (kind, axis, label) = if vertical {
                    (ConstraintKind::Vertical, "Vertical", "Vertical constraint")
                } else {
                    (
                        ConstraintKind::Horizontal,
                        "Horizontal",
                        "Horizontal constraint",
                    )
                };
                let new_command = || {
                    if vertical {
                        HorizontalConstraintCommand::vertical()
                    } else {
                        HorizontalConstraintCommand::new()
                    }
                };
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    let command = new_command();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else if handles.len() != 1 {
                    self.command_line
                        .push_error(&format!("{axis}: select exactly one compatible object."));
                } else {
                    let handle = handles[0];
                    let reference =
                        self.tabs[i]
                            .scene
                            .document
                            .get_entity(handle)
                            .and_then(|entity| {
                                HorizontalConstraintCommand::preselected_reference(entity, handle)
                            });
                    if let Some(reference) = reference {
                        let plane = self.tabs[i].ucs_xform().working_plane();
                        let direction = if vertical { plane.y } else { plane.x };
                        return Some(self.apply_cmd_result(CmdResult::AddHorizontalConstraint {
                            kind,
                            selection: HorizontalConstraintSelection::Reference(reference),
                            direction: codec::types::Vector3::new(
                                direction.x,
                                direction.y,
                                direction.z,
                            ),
                            label,
                        }));
                    }
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(&format!(
                        "Invalid selection for {axis}. Select a line segment, polyline segment, text, MText, major or minor axis of ellipse or elliptical arc."
                    ));
                    let command = new_command();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "FXCONSTRAINT" | "GCFIX" => {
                use crate::command::CmdResult;
                use crate::modules::parametric::FixConstraintCommand;
                use crate::scene::parametric_constraints::ConstraintKind;

                // One preselected whole curve applies at once (ribbon
                // "select first, then click"); anything else goes through
                // the reference's own point-or-object prompt.
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if let [handle] = handles.as_slice() {
                    let reference =
                        self.tabs[i]
                            .scene
                            .document
                            .get_entity(*handle)
                            .and_then(|entity| {
                                FixConstraintCommand::preselected_reference(entity, *handle)
                            });
                    if let Some(reference) = reference {
                        return Some(self.apply_cmd_result(CmdResult::AddParametricConstraint {
                            kind: ConstraintKind::Fixed,
                            refs: vec![reference],
                            driving_param: None,
                            label: "Fixed constraint",
                        }));
                    }
                }
                if !handles.is_empty() {
                    self.tabs[i].scene.deselect_all();
                }
                let command = FixConstraintCommand::new();
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            "CCONSTRAINT" | "GCCOINCIDENT" => {
                use crate::modules::parametric::CoincidentConstraintCommand;
                let new_cmd = CoincidentConstraintCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "GEOMCONSTRAINT" => {
                use crate::modules::parametric::GeomConstraintCommand;
                let new_cmd = GeomConstraintCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "DIMCONSTRAINT" => {
                use crate::modules::parametric::DimConstraintMenuCommand;
                self.command_line.push_output(&format!(
                    "Current settings:  Constraint form = {}",
                    self.constraint_form_name()
                ));
                let new_cmd = DimConstraintMenuCommand::new(self.dim_constraint_last);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "DCFORM" => {
                use crate::modules::parametric::ConstraintFormCommand;
                let new_cmd = ConstraintFormCommand::new(self.constraint_form_annotational);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            // DCFORM's answer, then on into DIMCONSTRAINT's options as the
            // reference does.
            cmd if cmd.starts_with("DCFORM_SET ") => {
                use crate::modules::parametric::DimConstraintMenuCommand;
                self.constraint_form_annotational = cmd
                    .trim_start_matches("DCFORM_SET ")
                    .trim()
                    .eq_ignore_ascii_case("Annotational");
                self.command_line.push_output(&format!(
                    "Current settings:  Constraint form = {}",
                    self.constraint_form_name()
                ));
                let new_cmd = DimConstraintMenuCommand::new(self.dim_constraint_last);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            // A dynamic dimension's value prompt (double-click).
            cmd if cmd.starts_with("DCVALUE ") => {
                let rest = cmd.trim_start_matches("DCVALUE ").trim();
                if let Some((name, input)) = rest.split_once(' ') {
                    self.apply_parameter_input(i, name.trim(), input);
                }
            }

            "-PARAMETERS" => {
                use crate::modules::parametric::ParametersCliCommand;
                let new_cmd = ParametersCliCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            cmd if cmd.starts_with("-PARAMETERS ") => {
                let rest = cmd.trim_start_matches("-PARAMETERS ").trim();
                let (op, args) = rest.split_once(' ').unwrap_or((rest, ""));
                match op {
                    "LIST" => {
                        let rule = "-".repeat(74);
                        let rows: Vec<String> = {
                            let table = self.tabs[i].scene.named_parameters();
                            table
                                .iter()
                                .map(|parameter| {
                                    let value =
                                        self.tabs[i].scene.parameter_value_text(&parameter.name);
                                    format!(
                                        "Parameter: {:<12} Expression: {:<21} Value: {value}",
                                        parameter.name, parameter.source
                                    )
                                })
                                .collect()
                        };
                        self.command_line.push_output(&rule);
                        for row in rows {
                            self.command_line.push_output(&row);
                        }
                        self.command_line.push_output(&rule);
                    }
                    "NEW" => {
                        if let Some((name, expression)) = args.split_once(' ') {
                            self.create_parameter(i, name.trim(), expression.trim());
                        }
                    }
                    "EDIT" => {
                        use crate::modules::parametric::ParametersCliCommand;
                        let name = args.trim().to_string();
                        let old = {
                            let table = self.tabs[i].scene.named_parameters();
                            table.get(&name).map(|parameter| {
                                let value = self.tabs[i].scene.parameter_value_text(&name);
                                format!("Old Expression = {}, Value = {value}", parameter.source)
                            })
                        };
                        match old {
                            Some(line) => {
                                self.command_line.push_output(&line);
                                let new_cmd = ParametersCliCommand::edit_expression(name);
                                self.command_line.push_info(&new_cmd.prompt());
                                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                            }
                            None => self
                                .command_line
                                .push_error(&format!("Parameter {name} not found.")),
                        }
                    }
                    "SET" => {
                        if let Some((name, expression)) = args.split_once(' ') {
                            self.apply_parameter_input(i, name.trim(), expression.trim());
                        }
                    }
                    "RENAME" => {
                        if let Some((old, new)) = args.split_once(' ') {
                            if let Err(error) = self.rename_parameter(i, old.trim(), new.trim()) {
                                self.command_line.push_error(&error);
                            }
                        }
                    }
                    "DELETE" => self.delete_parameter(i, args.trim()),
                    _ => {}
                }
            }

            "EDCONSTRAINT" => {
                use crate::modules::parametric::EqualDistanceConstraintCommand;
                let new_cmd = EqualDistanceConstraintCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "QCONSTRAINT" | "GCPERPENDICULAR" => {
                use crate::command::CmdResult;
                use crate::modules::parametric::PerpendicularConstraintCommand;

                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    let command = PerpendicularConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else if handles.len() != 2 {
                    self.command_line
                        .push_output("Select exactly two perpendicular-compatible objects.");
                } else {
                    let picks = handles
                        .iter()
                        .filter_map(|handle| {
                            let entity = self.tabs[i].scene.document.get_entity(*handle)?;
                            PerpendicularConstraintCommand::preselected_reference(entity, *handle)
                        })
                        .collect::<Vec<_>>();
                    if picks.len() == 2 && picks[0].reference != picks[1].reference {
                        return Some(self.apply_cmd_result(
                            CmdResult::AddPerpendicularConstraint {
                                first: picks[0].reference,
                                second: picks[1].reference,
                                first_fixed: picks[0].fixed_reference,
                                second_start: picks[1].start_reference,
                                label: "Perpendicular constraint",
                            },
                        ));
                    }
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(
                        "Invalid selection for Perpendicular. Select a line segment, polyline segment, text, MText, major or minor axis of ellipse or elliptical arc.",
                    );
                    let command = PerpendicularConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "TCONSTRAINT" => {
                use crate::command::CmdResult;
                use crate::modules::parametric::TangentConstraintCommand;

                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    let command = TangentConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else if handles.len() != 2 {
                    self.command_line
                        .push_output("Select exactly two tangent-compatible objects.");
                } else {
                    let refs = handles
                        .iter()
                        .filter_map(|handle| {
                            let entity = self.tabs[i].scene.document.get_entity(*handle)?;
                            TangentConstraintCommand::preselected_reference(entity, *handle)
                        })
                        .collect::<Vec<_>>();
                    if refs.len() == 2 && refs[0] != refs[1] {
                        return Some(self.apply_cmd_result(CmdResult::AddTangentConstraint {
                            first: refs[0],
                            second: refs[1],
                            label: "Tangent constraint",
                        }));
                    }
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(
                        "Invalid selection for Tangent. Select a line, polyline segment, circle, arc or ellipse.",
                    );
                    let command = TangentConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "ECONSTRAINT" | "GCEQUAL" => {
                use crate::modules::parametric::EqualConstraintCommand;
                // Both objects are picked inside the command, as in the
                // reference; a selection made beforehand is not used.
                self.tabs[i].scene.deselect_all();
                let command = EqualConstraintCommand::new();
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            "PCONSTRAINT" | "LCONSTRAINT" | "NRCONSTRAINT" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else if handles.len() != 2 {
                    self.command_line.push_output(
                        "Select exactly two entities (first = reference, second = the one that moves), then run this constraint again.",
                    );
                } else {
                    use crate::command::CmdResult;
                    use crate::scene::parametric_constraints::{ConstraintKind, ParametricRef};
                    let (kind, label) = match cmd {
                        "PCONSTRAINT" => (ConstraintKind::Parallel, "Parallel constraint"),
                        "LCONSTRAINT" => (ConstraintKind::Colinear, "Colinear constraint"),
                        _ => (ConstraintKind::Normal, "Normal constraint"),
                    };
                    return Some(self.apply_cmd_result(CmdResult::AddParametricConstraint {
                        kind,
                        refs: vec![
                            ParametricRef::whole(handles[0]),
                            ParametricRef::whole(handles[1]),
                        ],
                        driving_param: None,
                        label,
                    }));
                }
            }

            "GCCONCENTRIC" => {
                use crate::command::CmdResult;
                use crate::modules::parametric::ConcentricConstraintCommand;

                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    let command = ConcentricConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else {
                    let refs = handles
                        .iter()
                        .filter_map(|handle| {
                            let entity = self.tabs[i].scene.document.get_entity(*handle)?;
                            ConcentricConstraintCommand::preselected_reference(entity, *handle)
                        })
                        .collect::<Vec<_>>();
                    if handles.len() == 2 && refs.len() == 2 && refs[0] != refs[1] {
                        return Some(self.apply_cmd_result(CmdResult::AddConcentricConstraint {
                            first: refs[0],
                            second: refs[1],
                            label: "Concentric constraint",
                        }));
                    }
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(
                        "Invalid selection for Concentric. Select a circle, arc, ellipse or polyline arc segment.",
                    );
                    let command = refs
                        .first()
                        .copied()
                        .map(ConcentricConstraintCommand::with_first)
                        .unwrap_or_else(ConcentricConstraintCommand::new);
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "SYCONSTRAINT" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::parametric::SymmetricConstraintCommand;
                    let command = SymmetricConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                } else {
                    use crate::command::{CmdResult, SymmetricConstraintSelection};
                    use crate::modules::parametric::SymmetricConstraintCommand;

                    let refs = (handles.len() == 3)
                        .then(|| {
                            let first = self.tabs[i].scene.document.get_entity(handles[0])?;
                            let second = self.tabs[i].scene.document.get_entity(handles[1])?;
                            let axis = self.tabs[i].scene.document.get_entity(handles[2])?;
                            SymmetricConstraintCommand::preselected_refs(
                                (first, handles[0]),
                                (second, handles[1]),
                                (axis, handles[2]),
                            )
                        })
                        .flatten();
                    if let Some([first, second, axis]) = refs {
                        return Some(self.apply_cmd_result(CmdResult::AddSymmetricConstraint {
                            selection: SymmetricConstraintSelection::Objects(first, second),
                            axis,
                            label: "Symmetric constraint",
                        }));
                    }
                    self.tabs[i].scene.deselect_all();
                    self.command_line.push_error(
                        "Symmetric: select two compatible objects followed by a line axis.",
                    );
                    let command = SymmetricConstraintCommand::new();
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                }
            }

            "CPCONSTRAINT" | "MPCONSTRAINT" | "OCCONSTRAINT" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else if handles.len() != 1 {
                    self.command_line.push_output(
                        "Select exactly one entity (the circle or line the point should attach to), then run this constraint again.",
                    );
                } else {
                    use crate::modules::parametric::PointOnEntityConstraintCommand;
                    use crate::scene::parametric_constraints::ConstraintKind;
                    let (name, kind, label) = match cmd {
                        "CPCONSTRAINT" => (
                            "CPCONSTRAINT",
                            ConstraintKind::CenterPoint,
                            "Center point constraint",
                        ),
                        "MPCONSTRAINT" => (
                            "MPCONSTRAINT",
                            ConstraintKind::Midpoint,
                            "Midpoint constraint",
                        ),
                        _ => (
                            "OCCONSTRAINT",
                            ConstraintKind::PointOnCurve,
                            "Point on curve constraint",
                        ),
                    };
                    let new_cmd =
                        PointOnEntityConstraintCommand::new(name, kind, handles[0], label);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }

            "DCLINEAR" | "DCHORIZONTAL" | "DCVERTICAL" | "DCALIGNED" => {
                use crate::modules::parametric::{DimConstraintAxis, DimConstraintCommand};
                use crate::scene::parametric_constraints::next_dimensional_parameter_name;
                let axis = match cmd {
                    "DCHORIZONTAL" => DimConstraintAxis::Horizontal,
                    "DCVERTICAL" => DimConstraintAxis::Vertical,
                    "DCALIGNED" => DimConstraintAxis::Aligned,
                    _ => DimConstraintAxis::Linear,
                };
                self.dim_constraint_last = match cmd {
                    "DCHORIZONTAL" => "Horizontal",
                    "DCVERTICAL" => "Vertical",
                    "DCALIGNED" => "Aligned",
                    _ => "Linear",
                };
                let name = next_dimensional_parameter_name(self.tabs[i].scene.named_parameters());
                // Both constraint points are picked inside the command.
                self.tabs[i].scene.deselect_all();
                let command = DimConstraintCommand::new(axis, name);
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            "DCRADIUS" | "DCDIAMETER" => {
                use crate::modules::parametric::{DimConstraintAxis, DimConstraintCommand};
                use crate::scene::parametric_constraints::next_radial_parameter_name;
                let diameter = cmd == "DCDIAMETER";
                // Run on its own either one leaves DIMCONSTRAINT's default
                // alone; the Dispatch arm sets it when DIMCONSTRAINT is what
                // asked for this command.
                // The reference asks for the circle itself, whatever is
                // selected, so a pick-first set is left alone.
                let name =
                    next_radial_parameter_name(self.tabs[i].scene.named_parameters(), diameter);
                let command = DimConstraintCommand::new(
                    if diameter {
                        DimConstraintAxis::Diameter
                    } else {
                        DimConstraintAxis::Radius
                    },
                    name,
                );
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            "DCONSTRAINT" => {
                let handles = self.tabs[i].scene.selected_handles_in_order();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let sel = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&sel.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(sel));
                } else if handles.len() != 1 {
                    self.command_line.push_output(
                        "Select exactly one line or circle, then run this constraint again.",
                    );
                } else {
                    use crate::modules::parametric::{DistanceConstraintCommand, DistanceMode};
                    let (command_name, mode) = match cmd {
                        "DCLINEAR" => ("DCLINEAR", DistanceMode::Linear),
                        "DCHORIZONTAL" => ("DCHORIZONTAL", DistanceMode::X),
                        "DCVERTICAL" => ("DCVERTICAL", DistanceMode::Y),
                        "DCALIGNED" => ("DCALIGNED", DistanceMode::Aligned),
                        _ => ("DCONSTRAINT", DistanceMode::Auto),
                    };
                    match DistanceConstraintCommand::with_mode(
                        &self.tabs[i].scene,
                        handles[0],
                        command_name,
                        mode,
                    ) {
                        Some(new_cmd) => {
                            self.command_line.push_info(&new_cmd.prompt());
                            self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                        }
                        None => self
                            .command_line
                            .push_output("Select a line or a circle for a distance constraint."),
                    }
                }
            }

            "ACONSTRAINT" | "DCANGULAR" => {
                use crate::modules::parametric::{DimConstraintAxis, DimConstraintCommand};
                use crate::scene::parametric_constraints::{
                    angle_decimals, next_angular_parameter_name,
                };
                self.dim_constraint_last = "ANgular";
                let name = next_angular_parameter_name(self.tabs[i].scene.named_parameters());
                let decimals = angle_decimals(&self.tabs[i].scene.document, None);
                // Both sides are picked inside the command.
                self.tabs[i].scene.deselect_all();
                let command = DimConstraintCommand::new(DimConstraintAxis::Angular, name)
                    .with_angle_decimals(decimals);
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            // ── Model commands (3D primitives) ─────────────────────────────
            "CYLINDER" => {
                use crate::modules::model::cylinder_cmd::CylinderCommand;
                let new_cmd = CylinderCommand::new();
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }
            "BOX" | "WEDGE" | "CONE" | "SPHERE" | "PYRAMID" | "PYR" | "TORUS" => {
                use crate::modules::model::primitive_cmd::PrimitiveCommand;
                let new_cmd = PrimitiveCommand::new(cmd);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "SHELL" | "SOLIDEDIT" => {
                use crate::modules::model::shell_cmd::ShellCommand;
                let selected = self.tabs[i]
                    .scene
                    .selected_handles_in_order()
                    .into_iter()
                    .filter(|handle| !self.tabs[i].scene.is_layer_locked(*handle))
                    .filter(|handle| {
                        matches!(
                            self.tabs[i].scene.document.get_entity(*handle),
                            Some(codec::EntityType::Solid3D(_))
                        )
                    })
                    .collect::<Vec<_>>();
                // `then_some` evaluates its argument eagerly: indexing an empty
                // selection here crashed the app when SHELL was started with
                // nothing selected.
                let target = match selected.as_slice() {
                    [handle] => Some(*handle),
                    _ => None,
                };
                let new_cmd = if cmd == "SHELL" {
                    ShellCommand::direct(target)
                } else {
                    ShellCommand::solid_edit(target)
                };
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            // ── Solid booleans ─────────────────────────────────────────────
            "UNION" => {
                use crate::modules::model::boolean_cmd::BoolOp;
                if self.union_ready() {
                    return Some(self.solid_boolean(BoolOp::Union));
                }
                use crate::modules::draw::select::SelectObjectsCommand;
                let selection = SelectObjectsCommand::plain("UNION", "UNIONAPPLY");
                self.command_line.push_info(&selection.prompt());
                self.tabs[i].active_cmd = Some(Box::new(selection));
            }

            "UNIONAPPLY" => {
                use crate::modules::model::boolean_cmd::BoolOp;
                return Some(self.solid_boolean(BoolOp::Union));
            }

            "INTERSECT" => {
                use crate::modules::model::boolean_cmd::BoolOp;
                if !self.intersect_ready() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let selection = SelectObjectsCommand::new(cmd);
                    self.command_line.push_info(&selection.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(selection));
                } else {
                    return Some(self.solid_boolean(BoolOp::Intersect));
                }
            }

            "SUBTRACT" => {
                use crate::modules::model::boolean_cmd::SubtractCommand;
                let (bases, bases_have_mesh) = {
                    let scene = &self.tabs[i].scene;
                    let bases = scene
                        .selected_handles_in_order()
                        .into_iter()
                        .filter(|handle| !scene.is_layer_locked(*handle))
                        .filter(|handle| {
                            matches!(
                                scene.document.get_entity(*handle),
                                Some(
                                    codec::EntityType::Solid3D(_)
                                        | codec::EntityType::Region(_)
                                        | codec::EntityType::Surface(_)
                                        | codec::EntityType::Mesh(_)
                                        | codec::EntityType::PolygonMesh(_)
                                        | codec::EntityType::PolyfaceMesh(_)
                                )
                            )
                        })
                        .collect::<Vec<_>>();
                    let bases_have_mesh = bases.iter().any(|handle| {
                        matches!(
                            scene.document.get_entity(*handle),
                            Some(
                                codec::EntityType::Mesh(_)
                                    | codec::EntityType::PolygonMesh(_)
                                    | codec::EntityType::PolyfaceMesh(_)
                            )
                        )
                    });
                    (bases, bases_have_mesh)
                };
                self.tabs[i].scene.deselect_all();
                let subtract = SubtractCommand::new(bases, bases_have_mesh);
                self.command_line.push_info(&subtract.prompt());
                self.tabs[i].active_cmd = Some(Box::new(subtract));
            }

            // SECTIONCULL — erase what lies outside a section object.
            "SECTIONCULL" => {
                return Some(self.section_cull());
            }

            // INTERFERE — non-destructive intersect: solid from the overlap.
            "INTERFERE" => {
                return Some(self.solid_interfere());
            }

            // FLATSHOT — flatten the selected solid's edges to 2D lines at Z=0.
            "FLATSHOT" => {
                return Some(self.solid_flatshot());
            }

            // CONVTOSURFACE — convert the selected solid(s) to surface entities.
            "CONVTOSURFACE" => {
                return Some(self.solid_convtosurface());
            }

            "POLYSOLID" => {
                use crate::modules::model::polysolid_cmd::PolysolidCommand;
                let preselected = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .find(|(_, entity)| {
                        matches!(
                            entity,
                            codec::EntityType::Line(_)
                                | codec::EntityType::Arc(_)
                                | codec::EntityType::Circle(_)
                                | codec::EntityType::Ellipse(_)
                                | codec::EntityType::LwPolyline(_)
                                | codec::EntityType::Spline(_)
                        )
                    })
                    .map(|(handle, entity)| (handle, entity.clone()));
                let c = PolysolidCommand::new(preselected);
                self.command_line.push_info(&c.prompt());
                self.tabs[i].active_cmd = Some(Box::new(c));
            }

            // SPLINEFIT — fit a smooth spline through the selected polyline's points.
            "SPLINEFIT" | "FITSPLINE" => {
                return Some(self.fit_spline());
            }

            // REGION — convert exact closed planar profiles into regions.
            "REGION" | "REG" => {
                if self.tabs[i].scene.selected_entities().is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let command = SelectObjectsCommand::new("REGION");
                    self.command_line.push_info(&command.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(command));
                    return Some(iced::Task::none());
                }
                use codec::entities::Region;
                use codec::types::Vector3;
                let mut regions = Vec::new();
                let mut sources = Vec::new();
                for (handle, e) in self.tabs[i].scene.selected_entities().iter() {
                    if !matches!(e, codec::EntityType::Region(_)) {
                        let Some((plane, loops, true)) =
                            crate::scene::model::presspull_model::profile_geometry(e)
                        else {
                            continue;
                        };
                        let Some(body) = kernel::brep::planar_region(plane, &loops) else {
                            continue;
                        };
                        let mut region = Region::new();
                        region.point_of_reference =
                            Vector3::new(plane.origin[0], plane.origin[1], plane.origin[2]);
                        region.common.layer = self.tabs[i].active_layer.clone();
                        regions.push((region, body));
                        sources.push(*handle);
                    }
                }
                // Open inputs must share one geometric plane, independently of the UCS.
                let open_curves: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .iter()
                    .filter(|(handle, _)| !sources.contains(handle))
                    .filter_map(|(_, entity)| crate::entities::curve::entity_curve(entity))
                    .collect();
                let open_plane = kernel::space::common_curve_plane(&open_curves, 1.0e-6);
                let open_plane_rejected = !open_curves.is_empty() && open_plane.is_none();
                if let Some(plane) = open_plane {
                    let working_plane = crate::command::WorkingPlane::new(
                        glam::DVec3::from_array(plane.origin),
                        glam::DVec3::from_array(plane.x_axis),
                        glam::DVec3::from_array(plane.y_axis),
                    );
                    let selected_handles: rustc_hash::FxHashSet<_> = self.tabs[i]
                        .scene
                        .selected_entities()
                        .iter()
                        .map(|(handle, _)| *handle)
                        .collect();
                    let mut boundary_sources = self.tabs[i]
                        .scene
                        .boundary_sources_on_plane(working_plane, 1.0e-6);
                    boundary_sources.retain(|handle, _| {
                        selected_handles.contains(handle) && !sources.contains(handle)
                    });
                    for ring in crate::scene::boundary_faces(&boundary_sources, 1.0e-6) {
                        let paths = crate::scene::exact_hatch_paths(
                            std::slice::from_ref(&ring),
                            &[true],
                            &boundary_sources,
                            1.0e-6,
                        );
                        let Some(path) = paths.first() else {
                            continue;
                        };
                        let Some(curves) = path
                            .edges
                            .iter()
                            .map(crate::entities::hatch::edge_curve)
                            .collect::<Option<Vec<_>>>()
                        else {
                            continue;
                        };
                        let Some(body) = kernel::brep::planar_region(plane, &[curves]) else {
                            continue;
                        };
                        let mut region = Region::new();
                        region.point_of_reference =
                            Vector3::new(plane.origin[0], plane.origin[1], plane.origin[2]);
                        region.common.layer = self.tabs[i].active_layer.clone();
                        regions.push((region, body));
                        sources.extend(crate::scene::ring_source_handles(&ring, &boundary_sources));
                    }
                } else if open_plane_rejected {
                    self.command_line.push_error(
                        "REGION: open objects must form coplanar, noncollinear boundaries.",
                    );
                }
                if regions.is_empty() {
                    if !open_plane_rejected {
                        self.command_line.push_error(
                            "REGION: select closed planar profiles or connected coplanar edges.",
                        );
                    }
                } else {
                    self.push_undo_snapshot(i, "REGION");
                    let count = regions.len();
                    let mut created = Vec::with_capacity(count);
                    for (region, body) in regions {
                        let handle = self.add_region_model(region, body);
                        if handle.is_null() {
                            self.tabs[i].scene.rollback_new_entities(&created);
                            self.discard_last_undo_entry(i);
                            return Some(iced::Task::none());
                        }
                        created.push(handle);
                    }
                    if self.delete_objects != 0 {
                        sources.sort_by_key(|handle| handle.value());
                        sources.dedup();
                        self.tabs[i].scene.erase_entities(&sources);
                        self.refresh_properties();
                    }
                    // The command consumes the selection, kept sources included.
                    self.tabs[i].scene.deselect_all();
                    self.refresh_properties();
                    self.tabs[i].dirty = true;
                    self.command_line
                        .push_output(crate::tf!("REGION: created {count} region(s).").as_ref());
                }
            }

            // PYRAMID <radius> <height> [sides] keeps the direct numeric form.
            cmd if cmd.starts_with("PYRAMID ") || cmd.starts_with("PYR ") => {
                let nums: Vec<f64> = cmd
                    .split_whitespace()
                    .skip(1)
                    .filter_map(|s| s.parse::<f64>().ok())
                    .collect();
                if nums.len() >= 2 && nums[0] > 0.0 && nums[1] > 0.0 {
                    let sides = nums.get(2).map(|s| *s as usize).unwrap_or(4);
                    return Some(self.solid_pyramid(nums[0], nums[1], sides));
                }
                self.command_line.push_info(
                    crate::t!("Usage: PYRAMID <radius> <height> [sides]   (default 4 sides)")
                        .as_ref(),
                );
            }

            // SECTION [X|Y|Z] <value> — draw the cross-section outline of the solid.
            "SECTION" => {
                use crate::command::SelectThenKeywordCommand;
                let has_sel = !self.tabs[i].scene.selected_entities().is_empty();
                let c = SelectThenKeywordCommand::new(
                    "SECTION",
                    "SECTION  cutting-plane axis  [X / Y / Z]:",
                    vec![
                        ("X", "X", Some("SECTION  offset along X:")),
                        ("Y", "Y", Some("SECTION  offset along Y:")),
                        ("Z", "Z", Some("SECTION  offset along Z:")),
                    ],
                    has_sel,
                );
                self.command_line.push_info(&c.prompt());
                self.tabs[i].active_cmd = Some(Box::new(c));
            }
            cmd if cmd.starts_with("SECTION ") => {
                let parts: Vec<String> = cmd
                    .split_whitespace()
                    .skip(1)
                    .map(|s| s.to_uppercase())
                    .collect();
                let (axis, val_idx) = match parts.first().map(String::as_str) {
                    Some("X") => (0, 1),
                    Some("Y") => (1, 1),
                    Some("Z") => (2, 1),
                    _ => (2, 0),
                };
                match parts.get(val_idx).and_then(|s| s.parse::<f64>().ok()) {
                    Some(v) => return Some(self.solid_section(axis, v)),
                    None => self.command_line.push_info(
                        crate::t!(
                            "Usage: SECTION [X|Y|Z] <value>   (cross-sections the selected solid)"
                        )
                        .as_ref(),
                    ),
                }
            }

            "SECTIONPLANE" => {
                use crate::modules::model::sectionplane_cmd::SectionPlaneCommand;
                let (bounds, next_name) = {
                    let scene = &mut self.tabs[i].scene;
                    let solid_handles = scene
                        .document
                        .entities()
                        .filter_map(|entity| {
                            matches!(
                                entity,
                                codec::EntityType::Solid3D(_)
                                    | codec::EntityType::Surface(_)
                                    | codec::EntityType::Region(_)
                                    | codec::EntityType::Body(_)
                            )
                            .then_some(entity.common().handle)
                        })
                        .collect::<Vec<_>>();
                    scene.restore_solid_models(&solid_handles);
                    let bounds = solid_handles
                        .iter()
                        .filter_map(|handle| scene.solid_models.get(handle))
                        .filter_map(crate::scene::model::solid_model::extent)
                        .fold(None::<(glam::DVec3, glam::DVec3)>, |bounds, (low, high)| {
                            let low = glam::DVec3::from_array(low);
                            let high = glam::DVec3::from_array(high);
                            Some(match bounds {
                                None => (low, high),
                                Some((min, max)) => (min.min(low), max.max(high)),
                            })
                        });
                    let next_name = scene
                        .document
                        .entities()
                        .filter_map(|entity| {
                            let codec::EntityType::Extended(extended) = entity else {
                                return None;
                            };
                            let codec::entities::ExtendedEntityData::SectionObject(data) =
                                &extended.data
                            else {
                                return None;
                            };
                            data.name
                                .strip_prefix("Section Plane (")
                                .and_then(|name| name.strip_suffix(')'))
                                .and_then(|name| name.parse::<usize>().ok())
                        })
                        .max()
                        .unwrap_or(0)
                        + 1;
                    (bounds, next_name)
                };
                let command = SectionPlaneCommand::new(bounds, next_name);
                self.command_line.push_info(&command.prompt());
                self.tabs[i].active_cmd = Some(Box::new(command));
            }

            // 3DALIGN <18 numbers> — align the selected solid by 3 source→3 dest points.
            cmd if cmd == "3DALIGN"
                || cmd == "ALIGN3D"
                || cmd.starts_with("3DALIGN ")
                || cmd.starts_with("ALIGN3D ") =>
            {
                let n: Vec<f64> = cmd
                    .split_whitespace()
                    .skip(1)
                    .filter_map(|s| s.parse::<f64>().ok())
                    .collect();
                if n.len() >= 18 {
                    let src = [[n[0], n[1], n[2]], [n[3], n[4], n[5]], [n[6], n[7], n[8]]];
                    let dst = [
                        [n[9], n[10], n[11]],
                        [n[12], n[13], n[14]],
                        [n[15], n[16], n[17]],
                    ];
                    return Some(self.solid_align3d(src, dst));
                }
                self.command_line.push_info(
                    crate::t!("Usage: 3DALIGN <sx1 sy1 sz1 … sx3 sy3 sz3  dx1 dy1 dz1 … dx3 dy3 dz3>  (18 numbers: 3 source then 3 destination points)").as_ref(),
                );
            }

            // 3DMIRROR [X|Y|Z] — add a mirror of the selected solid across a plane.
            "3DMIRROR" | "MIRROR3D" => {
                use crate::command::SelectThenKeywordCommand;
                let has_sel = !self.tabs[i].scene.selected_entities().is_empty();
                let c = SelectThenKeywordCommand::new(
                    "3DMIRROR",
                    "3DMIRROR  mirror plane  [X / Y / Z]:",
                    vec![("X", "X", None), ("Y", "Y", None), ("Z", "Z", None)],
                    has_sel,
                );
                self.command_line.push_info(&c.prompt());
                self.tabs[i].active_cmd = Some(Box::new(c));
            }
            cmd if cmd.starts_with("3DMIRROR ") || cmd.starts_with("MIRROR3D ") => {
                let parts: Vec<String> = cmd
                    .split_whitespace()
                    .skip(1)
                    .map(|s| s.to_uppercase())
                    .collect();
                let axis = match parts.first().map(String::as_str) {
                    Some("X") => 0,
                    Some("Y") => 1,
                    Some("Z") => 2,
                    _ => {
                        self.command_line.push_info(
                            crate::t!("Usage: 3DMIRROR [X|Y|Z]   (mirrors the selected solid across that plane)").as_ref(),
                        );
                        return None;
                    }
                };
                return Some(self.solid_mirror3d(axis));
            }

            // 3DROTATE [X|Y|Z] <angle> — rotate the selected solid about an axis.
            // 3DROTATE — any objects about an axis through a base point.
            "3DROTATE" | "ROTATE3D" => {
                let handles: Vec<_> = self.tabs[i]
                    .scene
                    .selected_entities()
                    .into_iter()
                    .map(|(h, _)| h)
                    .collect();
                if handles.is_empty() {
                    use crate::modules::draw::select::SelectObjectsCommand;
                    let cmd = SelectObjectsCommand::new("3DROTATE");
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                } else {
                    use crate::modules::draw::modify::rotate::RotateCommand;
                    let wires = self.tabs[i].scene.wire_models_for(&handles);
                    let new_cmd = RotateCommand::new_3d(handles, wires);
                    self.command_line.push_info(&new_cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(new_cmd));
                }
            }
            cmd if cmd.starts_with("3DROTATE ") || cmd.starts_with("ROTATE3D ") => {
                let parts: Vec<String> = cmd
                    .split_whitespace()
                    .skip(1)
                    .map(|s| s.to_uppercase())
                    .collect();
                let axis = match parts.first().map(String::as_str) {
                    Some("X") => 0,
                    Some("Y") => 1,
                    _ => 2,
                };
                let angle: Option<f64> = parts.iter().find_map(|s| s.parse::<f64>().ok());
                match angle {
                    Some(a) => return Some(self.solid_rotate3d(axis, a)),
                    None => self.command_line.push_info(
                        crate::t!("Usage: 3DROTATE [X|Y|Z] <angle>   (rotates the selected solid)")
                            .as_ref(),
                    ),
                }
            }

            "SLICE" | "SL" => {
                use crate::modules::model::slice_cmd::SliceCommand;
                let (targets, centre, radius, view_normal) = {
                    let scene = &mut self.tabs[i].scene;
                    let mut targets = scene
                        .selected_handles_in_order()
                        .into_iter()
                        .filter(|handle| !scene.is_layer_locked(*handle))
                        .filter(|handle| {
                            matches!(
                                scene.document.get_entity(*handle),
                                Some(
                                    codec::EntityType::Solid3D(_)
                                        | codec::EntityType::Surface(_)
                                        | codec::EntityType::Mesh(_)
                                        | codec::EntityType::PolygonMesh(_)
                                        | codec::EntityType::PolyfaceMesh(_)
                                )
                            )
                        })
                        .collect::<Vec<_>>();
                    scene.restore_solid_models(&targets);
                    let mesh_extent = |handle: &codec::Handle| {
                        let entity = scene.document.get_entity(*handle)?;
                        let (vertices, _) = crate::entities::mesh::mesh_polygons(entity)?;
                        vertices.iter().fold(None, |bounds, point| {
                            let (mut min, mut max) = bounds.unwrap_or((*point, *point));
                            for axis in 0..3 {
                                min[axis] = f64::min(min[axis], point[axis]);
                                max[axis] = f64::max(max[axis], point[axis]);
                            }
                            Some((min, max))
                        })
                    };
                    targets.retain(|handle| {
                        scene.solid_models.contains_key(handle) || mesh_extent(handle).is_some()
                    });
                    let bounds = targets
                        .iter()
                        .filter_map(|handle| match scene.solid_models.get(handle) {
                            Some(body) => crate::scene::model::solid_model::extent(body),
                            None => mesh_extent(handle),
                        })
                        .fold(None::<([f64; 3], [f64; 3])>, |bounds, (low, high)| {
                            Some(match bounds {
                                None => (low, high),
                                Some((mut min, mut max)) => {
                                    for axis in 0..3 {
                                        min[axis] = min[axis].min(low[axis]);
                                        max[axis] = max[axis].max(high[axis]);
                                    }
                                    (min, max)
                                }
                            })
                        });
                    let (centre, radius) =
                        bounds.map_or((glam::DVec3::ZERO, 10.0), |(min, max)| {
                            let min = glam::DVec3::from_array(min);
                            let max = glam::DVec3::from_array(max);
                            ((min + max) * 0.5, (max - min).length().max(2.0) * 0.65)
                        });
                    (targets, centre, radius, scene.active_gaze_dir().as_dvec3())
                };
                let c = SliceCommand::new(targets, view_normal, centre, radius);
                self.command_line.push_info(&c.prompt());
                self.tabs[i].active_cmd = Some(Box::new(c));
            }
            cmd if cmd.starts_with("SLICE ") || cmd.starts_with("SL ") => {
                let parts: Vec<String> = cmd
                    .split_whitespace()
                    .skip(1)
                    .map(|s| s.to_uppercase())
                    .collect();
                let (axis, val_idx) = match parts.first().map(String::as_str) {
                    Some("X") => (0, 1),
                    Some("Y") => (1, 1),
                    Some("Z") => (2, 1),
                    _ => (2, 0), // default Z plane
                };
                let value: Option<f64> = parts.get(val_idx).and_then(|s| s.parse().ok());
                let keep_low = !parts.iter().any(|s| s == "TOP");
                match value {
                    Some(v) => {
                        let (origin, x, normal) = match axis {
                            0 => ([v, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 0.0, 0.0]),
                            1 => ([0.0, v, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]),
                            _ => ([0.0, 0.0, v], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]),
                        };
                        let plane = kernel::space::Plane::orthonormal(origin, x, normal)
                            .expect("fixed world axes define a plane");
                        let side = glam::DVec3::from_array(origin)
                            + glam::DVec3::from_array(normal) * if keep_low { -1.0 } else { 1.0 };
                        return Some(self.slice_selected(plane, Some(side)));
                    }
                    None => self.command_line.push_info(
                        crate::t!(
                            "Usage: SLICE [X|Y|Z] <value> [TOP|BOTTOM]   (cuts the selected solid)"
                        )
                        .as_ref(),
                    ),
                }
            }

            // ── Annotate commands ──────────────────────────────────────────
            "TEXT" => {
                use crate::modules::annotate::text::TextCommand;
                let (defaults, styles, annotation_multiplier) = {
                    let scene = &self.tabs[i].scene;
                    let annotation_multiplier = scene.creation_annotation_multiplier();
                    let defaults =
                        crate::scene::creation_style::current_text_defaults(&scene.document);
                    let styles = scene.document.text_styles.iter().cloned().collect();
                    (defaults, styles, annotation_multiplier)
                };
                let new_cmd = TextCommand::with_defaults(defaults, styles, annotation_multiplier);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "DDEDIT" => {
                use crate::modules::annotate::ddedit::DdeditCommand;
                // A single text entity already selected opens its in-place
                // editor directly; otherwise prompt for a pick.
                let sel = self.tabs[i].scene.selected_entities();
                let editable = (sel.len() == 1).then(|| sel[0].0).filter(|h| {
                    self.tabs[i].scene.document.get_entity(*h).is_some_and(|e| {
                        super::super::text_inline::read_text_field(e).is_some()
                            || matches!(e, codec::EntityType::Leader(_))
                    })
                });
                if let Some(h) = editable {
                    return Some(self.begin_text_edit(h));
                }
                if sel.len() == 1 {
                    self.command_line
                        .push_error(crate::t!("DDEDIT: selected entity is not text.").as_ref());
                } else {
                    let cmd = DdeditCommand::new();
                    self.command_line.push_info(&cmd.prompt());
                    self.tabs[i].active_cmd = Some(Box::new(cmd));
                }
            }

            "MTEXT" => {
                use crate::modules::annotate::mtext::MTextCommand;
                let height = crate::scene::creation_style::current_text_defaults(
                    &self.tabs[i].scene.document,
                )
                .height;
                let style = self.tabs[i]
                    .scene
                    .document
                    .header
                    .current_text_style_name
                    .clone();
                // An annotative style's default height is on paper; the editor
                // and the entity work in the model height of this scale.
                let height = if crate::scene::annotative::text_style_is_annotative(
                    &self.tabs[i].scene.document,
                    &style,
                ) {
                    height * self.tabs[i].scene.creation_annotation_multiplier()
                } else {
                    height
                };
                let new_cmd = MTextCommand::with_defaults(height, style);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "TEXTEDIT" | "TEDIT" => {
                use crate::modules::annotate::textedit::TexteditCommand;
                let mode_str = if self.texteditmode {
                    "Single"
                } else {
                    "Multiple"
                };
                self.command_line
                    .push_output(crate::tf!("Current settings: Edit mode = {}", mode_str).as_ref());
                let new_cmd = TexteditCommand::new(self.texteditmode);
                self.command_line.push_info(&new_cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(new_cmd));
            }

            "TEXTEDITMODE" => {
                use crate::modules::annotate::textedit::TexteditmodeCommand;
                let cmd = TexteditmodeCommand::new(self.texteditmode);
                self.command_line.push_info(&cmd.prompt());
                self.tabs[i].active_cmd = Some(Box::new(cmd));
            }

            _ => return None,
        }
        Some(self.finish_dispatch(cmd))
    }
}

#[cfg(test)]
mod region_tests {
    use crate::app::OpenCADStudio;

    #[test]
    fn region_respects_delobj_and_preserves_unconverted_sources() {
        for delete_sources in [false, true] {
            let mut app = OpenCADStudio::new_for_test();
            app.automation_op(r#"{"op":"new"}"#);
            app.automation_op(r#"{"op":"run","cmd":"CIRCLE 5,5 3"}"#);
            app.automation_op(r#"{"op":"run","cmd":"LINE 0,0 10,10"}"#);
            let i = app.active_tab;
            let sources: Vec<_> = app.tabs[i]
                .scene
                .document
                .entities()
                .map(|entity| {
                    (
                        entity.common().handle,
                        matches!(entity, codec::EntityType::Circle(_)),
                    )
                })
                .collect();
            assert_eq!(sources.len(), 2);
            let handles: Vec<_> = sources.iter().map(|(handle, _)| *handle).collect();
            app.tabs[i].scene.select_entities(&handles);
            app.delete_objects = i16::from(delete_sources);

            let _ = app.dispatch_command("REGION");

            for (handle, is_circle) in &sources {
                assert_eq!(
                    app.tabs[i].scene.document.get_entity(*handle).is_some(),
                    !delete_sources || !is_circle,
                );
            }
            let region_count = app.tabs[i]
                .scene
                .document
                .entities()
                .filter(|entity| matches!(entity, codec::EntityType::Region(_)))
                .count();
            assert_eq!(region_count, 1);

            app.automation_op(r#"{"op":"undo"}"#);
            for (handle, _) in &sources {
                assert!(app.tabs[i].scene.document.get_entity(*handle).is_some());
            }
            assert_eq!(app.tabs[i].scene.document.entities().count(), 2);
        }
    }
}

#[cfg(test)]
mod degenerate_constraint_tests {
    use crate::app::OpenCADStudio;

    /// Retaining a zero-length line's size used to hand the solver a NaN
    /// Jacobian, and its SVD fallback never returned.
    #[test]
    fn equal_constraint_with_a_zero_length_line_returns() {
        let mut app = OpenCADStudio::new_for_test();
        app.automation_op(r#"{"op":"new"}"#);
        app.automation_op(r#"{"op":"run","cmd":"LINE 0,0 0,0 "}"#);
        app.automation_op(r#"{"op":"run","cmd":"LINE 5,5 20,7 "}"#);
        app.automation_op(r#"{"op":"select","type":"Line"}"#);
        app.automation_op(r#"{"op":"run","cmd":"ECONSTRAINT"}"#);
        let lines = app.automation_op(r#"{"op":"query","type":"Line","detail":"geometry"}"#);
        assert_eq!(lines["ok"], true, "{lines}");
    }
}
