//! Device integrations. Camera ownership and CAD commands stay in the app.
pub(crate) mod spacemouse;
pub(crate) mod touch;
pub(crate) mod trackpad;
