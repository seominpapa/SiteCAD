//! Embedded type registry generated at build time.
//!
//! The JSON embedded here is produced by tracing every editor record root and
//! its dependent `opencadcodec` types with `serde-reflection`, then mapping the
//! result into a stable, language-binding-friendly schema defined in
//! [`crate::type_registry_types`]. The registry is embedded via
//! `include_str!(concat!(env!("OUT_DIR"), "/type_registry.json"))` so the
//! `host` feature is not required to read it.
//!
//! The registry covers the complete entity, object, symbol-table, header, and
//! document-record roots used by the editor. Language bindings and tooling can
//! inspect every variant without pulling the full `opencadcodec` dependency tree.

pub use crate::type_registry_types::*;

/// The embedded type registry as a JSON string.
pub const EMBEDDED_TYPE_REGISTRY_JSON: &str =
    include_str!(concat!(env!("OUT_DIR"), "/type_registry.json"));

/// Convenience accessor for the embedded type registry JSON.
pub fn get_embedded_type_registry_json() -> &'static str {
    EMBEDDED_TYPE_REGISTRY_JSON
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_type_registry_is_valid_json() {
        let json = get_embedded_type_registry_json();
        assert!(!json.is_empty());
        let registry: TypeRegistry = serde_json::from_str(json).expect("valid TypeRegistry JSON");
        assert!(!registry.types.is_empty());
    }

    #[test]
    fn embedded_type_registry_contains_expected_acadrust_types() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");

        for name in [
            "Point",
            "Line",
            "Circle",
            "MText",
            "EntityCommon",
            "XRecord",
            "XRecordEntry",
            "XRecordValue",
            "XRecordValueType",
            "XRecordSection",
            "DictionaryCloningFlags",
            "KnownXRecordKind",
            "ProxyObjectReference",
            "ProxyReferenceKind",
        ] {
            assert!(
                registry.types.contains_key(&TypeId::new(name)),
                "registry should contain {}",
                name
            );
        }
    }

    #[test]
    fn embedded_type_registry_mtext_is_struct_with_expected_fields() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");

        let mtext = registry
            .types
            .get(&TypeId::new("MText"))
            .expect("MText in registry");
        assert_eq!(mtext.kind, TypeKind::Struct);

        let field_names: Vec<&str> = mtext.fields.iter().map(|f| f.name.as_str()).collect();
        for expected in [
            "common",
            "value",
            "insertion_point",
            "height",
            "attachment_point",
        ] {
            assert!(
                field_names.contains(&expected),
                "MText should have field {}",
                expected
            );
        }
    }

    #[test]
    fn embedded_type_registry_point_is_struct_with_expected_fields() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");

        let point = registry
            .types
            .get(&TypeId::new("Point"))
            .expect("Point in registry");
        assert_eq!(point.kind, TypeKind::Struct);

        let field_names: Vec<&str> = point.fields.iter().map(|f| f.name.as_str()).collect();
        for expected in ["common", "location", "thickness", "normal"] {
            assert!(
                field_names.contains(&expected),
                "Point should have field {}",
                expected
            );
        }

        let common = point
            .fields
            .iter()
            .find(|f| f.name == "common")
            .expect("common field");
        assert_eq!(common.type_id.as_str(), "EntityCommon");
    }

    #[test]
    fn embedded_type_registry_contains_every_entity_and_object_variant() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");
        let entities = registry
            .types
            .get(&TypeId::new("EntityType"))
            .expect("EntityType in complete registry");
        let objects = registry
            .types
            .get(&TypeId::new("ObjectType"))
            .expect("ObjectType in complete registry");
        assert_eq!(entities.variants.len(), 48);
        assert_eq!(objects.variants.len(), 36);
        for root in [
            "HeaderVariables",
            "SummaryInfo",
            "LineType",
            "TextStyle",
            "BlockRecord",
            "DimStyle",
            "AppId",
            "View",
            "VPort",
            "Ucs",
            "VxTableRecord",
            "DxfClass",
            "BlockVisibilityParameter",
            "FieldDef",
            "DgnLsDefinition",
            "DgnLsComponent",
            "NotificationCollection",
            "Preview",
            "EntitySectionViewStyle",
        ] {
            assert!(
                registry.types.contains_key(&TypeId::new(root)),
                "missing {root}"
            );
        }
    }

    #[test]
    fn type_id_as_str_returns_inner_value() {
        let id = TypeId::new("Point");
        assert_eq!(id.as_str(), "Point");
    }

    #[test]
    fn embedded_type_registry_xrecord_is_struct_with_expected_fields() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");

        let xrecord = registry
            .types
            .get(&TypeId::new("XRecord"))
            .expect("XRecord in registry");
        assert_eq!(xrecord.kind, TypeKind::Struct);

        let field_names: Vec<&str> = xrecord.fields.iter().map(|f| f.name.as_str()).collect();
        for expected in [
            "handle",
            "owner",
            "reactors",
            "xdictionary_handle",
            "name",
            "cloning_flags",
            "entries",
            "object_references",
            "preserve_object_reference_stream",
            "entries_complete",
            "raw_data",
            "raw_dwg_handle_bits",
        ] {
            assert!(
                field_names.contains(&expected),
                "XRecord should have field {}",
                expected
            );
        }
    }

    #[test]
    fn embedded_type_registry_xrecord_value_is_enum_with_expected_variants() {
        let registry: TypeRegistry = serde_json::from_str(get_embedded_type_registry_json())
            .expect("valid TypeRegistry JSON");

        let value = registry
            .types
            .get(&TypeId::new("XRecordValue"))
            .expect("XRecordValue in registry");
        assert_eq!(value.kind, TypeKind::Enum);

        let variant_names: Vec<&str> = value.variants.iter().map(|v| v.name.as_str()).collect();
        for expected in [
            "String", "Double", "Int16", "Int32", "Int64", "Byte", "Bool", "Handle", "Point3D",
            "Chunk",
        ] {
            assert!(
                variant_names.contains(&expected),
                "XRecordValue should have variant {}",
                expected
            );
        }
    }
}
